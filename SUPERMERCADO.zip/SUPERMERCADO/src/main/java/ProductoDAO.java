import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ProductoDAO {
    // Método para agregar un producto a la base de datos
    public void agregarProducto(String nombre, double precio) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        String sql = "INSERT INTO productos (nombre, precio) VALUES (?, ?)";
        
        try {
            conn = ConexionBD.getConnection(); // Obtiene la conexión
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, nombre); // Establece el valor del primer parámetro (nombre)
            stmt.setDouble(2, precio); // Establece el valor del segundo parámetro (precio)
            
            // Ejecuta la sentencia SQL
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Producto agregado exitosamente");
            }
        } catch (SQLException e) {
            System.out.println("Error al agregar el producto");
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

public class Main {
    public static void main(String[] args) {
        ProductoDAO productoDAO = new ProductoDAO();
        
        // Agregar un producto
        productoDAO.agregarProducto("Producto Ejemplo", 99.99);
    }
}
}
