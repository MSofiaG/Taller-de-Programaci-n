import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    // Datos de conexión a la base de datos
    private static final String URL = "jdbc:mysql://localhost:3306/productos_db";
    private static final String USER = "root@localhost"; // Cambia esto por tu usuario de MySQL
    private static final String PASSWORD = "DanteG19"; // Cambia esto por tu contraseña de MySQL

    // Método para obtener una conexión a la base de datos
    public static Connection getConnection() throws SQLException {
        Connection conn = null;
        try {
            // Registrar el controlador JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Obtener la conexión
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            System.out.println("Error al cargar el driver JDBC");
            e.printStackTrace();
        }
        return conn;
    }
}
