
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet(urlPatterns = {"/miServlet3"})
@MultipartConfig
public class miServlet3 extends HttpServlet {

    private static final String URL = "jdbc:mysql://localhost:3306/productos_db";
    private static final String USER = "tu_usuario";
    private static final String PASSWORD = "DanteG19";

    private void handleProductPublication(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        String fechaVencimiento = request.getParameter("fechaVencimiento");
        String tipo = request.getParameter("producto");
        String precio = request.getParameter("precio");
        String cantidad = request.getParameter("cantidad");

        Part foto = request.getPart("foto");
        String fotoNombre = foto.getSubmittedFileName();

        // Guardar la imagen en el servidor
        // ...

        // Conectar a la base de datos y agregar el producto
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String sql = "INSERT INTO productos (nombre, descripcion, fecha_vencimiento, tipo, precio, cantidad, foto) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, nombre);
                statement.setString(2, descripcion);
                statement.setString(3, fechaVencimiento);
                statement.setString(4, tipo);
                statement.setString(5, precio);
                statement.setString(6, cantidad);
                statement.setString(7, fotoNombre);
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ServletException("Error al agregar el producto", e);
        }

        request.setAttribute("nombre", nombre);
        request.setAttribute("descripcion", descripcion);
        request.setAttribute("fechaVencimiento", fechaVencimiento);
        request.setAttribute("tipo", tipo);
        request.setAttribute("precio", precio);
        request.setAttribute("cantidad", cantidad);
        request.setAttribute("foto", fotoNombre);

        RequestDispatcher dispatcher = request.getRequestDispatcher("index_4.jsp");
        dispatcher.forward(request, response);
    }

    private void handleProductModification(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        String productId = request.getParameter("selectedRowId");
        String nuevoNombre = request.getParameter("modificarNombre");
        String nuevaDescripcion = request.getParameter("modificarDescripcion");
        String nuevaFecha = request.getParameter("modificarFecha");
        String nuevoTipo = request.getParameter("modificarTipo");
        String nuevoPrecio = request.getParameter("modificarPrecio");
        String nuevaCantidad = request.getParameter("modificarCantidad");

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String sql = "UPDATE productos SET nombre = ?, descripcion = ?, fecha_vencimiento = ?, tipo = ?, precio = ?, cantidad = ? WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, nuevoNombre);
                statement.setString(2, nuevaDescripcion);
                statement.setString(3, nuevaFecha);
                statement.setString(4, nuevoTipo);
                statement.setString(5, nuevoPrecio);
                statement.setString(6, nuevaCantidad);
                statement.setString(7, productId);
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ServletException("Error al modificar el producto", e);
        }

        // Redirigir a la página que muestra la lista actualizada
        response.sendRedirect("index_4.jsp");
    }

    private void handleProductDeletion(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        String productId = request.getParameter("selectedRowId");

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String sql = "DELETE FROM productos WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, productId);
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ServletException("Error al eliminar el producto", e);
        }

        // Redirigir a la página que muestra la lista actualizada
        response.sendRedirect("index_4.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("Publicar".equals(action)) {
            handleProductPublication(request, response);
        } else if ("Modificar".equals(action)) {
            handleProductModification(request, response);
        } else if ("Eliminar".equals(action)) {
            handleProductDeletion(request, response);
        } else {
            response.getWriter().println("Acción no válida.");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        doPost(request, response);
    }
}
