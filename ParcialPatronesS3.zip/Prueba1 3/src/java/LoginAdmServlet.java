import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginAdmServlet")
public class LoginAdmServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Obtener las credenciales del formulario
        String correo = request.getParameter("correoU");
        String contra = request.getParameter("contraU");

        // Verificar las credenciales en la base de datos
        try (Connection connection = ConexionBD.getConnection()) {
            AdministradorDAO adminDAO = new AdministradorDAO(connection);
            
            // Verificar si el usuario existe
            boolean credencialesCorrectas = adminDAO.verificarCredenciales(correo, contra);
            
            if (credencialesCorrectas) {
                // Redirigir a la página de administración
                response.sendRedirect("index3Adm.html");
            } else {
                // Si las credenciales son incorrectas, redirigir a la misma página con un error
                response.sendRedirect("index1Adm.html?error=credenciales");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error en la conexión a la base de datos.");
        }
    }

    @Override
    public String getServletInfo() {
        return "";
    }
}
