import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClienteDAO {
    private Connection connection;

    public ClienteDAO(Connection connection) {
        this.connection = connection;
    }

    // Método para registrar un nuevo cliente
    public boolean registrarCliente(String nombre, String apellido, String nit, String correo, String contra, String telefono, int localidad) {
        String query = "INSERT INTO clientes2 (nombre, apellido, nit, correo, contra, telefono, localidad, estado) VALUES (?, ?, ?, ?, ?, ?, ?, 'inactivo')";

        try (PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, nombre);
            pst.setString(2, apellido);
            pst.setString(3, nit);
            pst.setString(4, correo);
            pst.setString(5, contra); // Asegúrate de hacer un hash de la contraseña
            pst.setString(6, telefono);
            pst.setInt(7, localidad);

            int result = pst.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para verificar las credenciales del cliente
    public boolean verificarCredenciales(String correo, String contra) {
        String sql = "SELECT COUNT(*) FROM clientes2 WHERE correo = ? AND contra = ?";
    
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, correo);
            statement.setString(2, contra);  // Aquí deberías comparar el hash si usas hashing
            ResultSet resultSet = statement.executeQuery();
        
            // Si se encuentra un registro, el usuario existe
            if (resultSet.next()) {
                if (resultSet.getInt(1) > 0) {
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Método para verificar si la cuenta está activa
    public boolean verificarCuentaActiva(String correo) {
        String sql = "SELECT estado FROM clientes2 WHERE correo = ?";
    
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, correo);
            ResultSet resultSet = statement.executeQuery();
        
            if (resultSet.next()) {
                String estado = resultSet.getString("estado");
                return "activo".equals(estado);  // Si el estado es 'activo', la cuenta está activa
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
