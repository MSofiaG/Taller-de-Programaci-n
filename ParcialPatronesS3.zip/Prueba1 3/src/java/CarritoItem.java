public class CarritoItem {
    private int id;          // ID único para el item del carrito
    private int carritoId;   // ID del carrito al que pertenece el item
    private int productoId;  // ID del producto
    private int cantidad;    // Cantidad del producto en el carrito
    private String nombre;   // Nombre del producto
    private double precio;   // Precio del producto

    // Constructor vacío
    public CarritoItem() {
    }

    // Constructor con parámetros
    public CarritoItem(int id, int carritoId, int productoId, int cantidad, String nombre, double precio) {
        this.id = id;
        this.carritoId = carritoId;
        this.productoId = productoId;
        this.cantidad = cantidad;
        this.nombre = nombre;
        this.precio = precio;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCarritoId() {
        return carritoId;
    }

    public void setCarritoId(int carritoId) {
        this.carritoId = carritoId;
    }

    public int getProductoId() {
        return productoId;
    }

    public void setProductoId(int productoId) {
        this.productoId = productoId;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    // Calcular el subtotal del producto (cantidad * precio)
    public double getSubtotal() {
        return cantidad * precio;
    }

    @Override
    public String toString() {
        return "CarritoItem{" +
                "id=" + id +
                ", carritoId=" + carritoId +
                ", productoId=" + productoId +
                ", cantidad=" + cantidad +
                ", nombre='" + nombre + '\'' +
                ", precio=" + precio +
                '}';
    }
}
