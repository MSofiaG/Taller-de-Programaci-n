import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/PagoServlet")
public class PagoServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private CarritoDAO carritoDAO;

    @Override
    public void init() throws ServletException {
        carritoDAO = new CarritoDAO(); // Inicializar el CarritoDAO
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener el carritoId de la sesión
        HttpSession session = request.getSession();
        Integer carritoId = (Integer) session.getAttribute("carritoId");

        if (carritoId == null) {
            response.sendRedirect("index.html");  // Redirigir si no hay un carrito
            return;
        }

        try {
            // Obtener los productos del carrito desde la base de datos
            List<CarritoItem> carritoItems = carritoDAO.obtenerCarrito(carritoId);

            // Pasar los items del carrito al JSP
            request.setAttribute("carritoItems", carritoItems);

            // Redirigir a la página de resumen de compra
            request.getRequestDispatcher("/resumenCompra.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al obtener los productos del carrito.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener el carritoId de la sesión
        HttpSession session = request.getSession();
        Integer carritoId = (Integer) session.getAttribute("carritoId");

        if (carritoId == null) {
            response.sendRedirect("index.html");  // Redirigir si no hay un carrito
            return;
        }

        // Obtener el método de pago seleccionado
        String metodoPago = request.getParameter("metodoPago");

        if (metodoPago == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "No se seleccionó un método de pago.");
            return;
        }

        // Aquí puedes agregar la lógica para procesar el pago (por ejemplo, usando un API de pagos)

        // Después de procesar el pago, actualizar el estado del carrito
        try {
            // Obtener los productos del carrito
            List<CarritoItem> carritoItems = carritoDAO.obtenerCarrito(carritoId);

            // Guardar el carrito (en caso de que necesites actualizar el estado en la base de datos)
            carritoDAO.guardarCarrito(carritoItems, carritoId);

            // Eliminar el carrito de la sesión, ya que el pago se ha procesado
            session.removeAttribute("carritoId");

            // Redirigir a una página de confirmación de pago
            response.sendRedirect("confirmacionPago.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al procesar el pago.");
        }
    }
}
