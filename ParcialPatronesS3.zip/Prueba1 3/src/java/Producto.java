public class Producto {

    private int id;
    private String nombre;
    private String descripcion;
    private String fechaVencimiento;
    private String tipo;
    private String precio;
    private String cantidad;
    private String foto;

    // Constructor sin parámetros (constructor por defecto)
    public Producto() {
    }

    // Constructor con todos los parámetros (con foto)
    public Producto(String nombre, String descripcion, String fechaVencimiento, String tipo, String precio, String cantidad, String foto) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fechaVencimiento = fechaVencimiento;
        this.tipo = tipo;
        this.precio = precio;
        this.cantidad = cantidad;
        this.foto = foto;
    }

    // Constructor con id (para productos existentes)
    public Producto(int id, String nombre, String descripcion, String fechaVencimiento, String tipo, String precio, String cantidad, String foto) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fechaVencimiento = fechaVencimiento;
        this.tipo = tipo;
        this.precio = precio;
        this.cantidad = cantidad;
        this.foto = foto;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(String fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
}
