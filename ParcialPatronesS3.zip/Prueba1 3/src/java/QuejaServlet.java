import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/QuejaServlet")
public class QuejaServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Parámetros de conexión a la base de datos
    private String jdbcURL = "jdbc:mysql://localhost:3306/CaminosSostenibles?serverTimezone=UTC";
    private String jdbcUsername = "root";
    private String jdbcPassword = "giusepeymia";

    // Método para obtener la conexión a la base de datos
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
    }

    // Método para manejar la solicitud GET (ver quejas)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String sql = "SELECT * FROM quejas"; // Consulta para obtener todas las quejas
        List<Queja> quejasList = new ArrayList<>();

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            // Procesar los resultados y agregar las quejas a la lista
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String correo = resultSet.getString("correo");
                String mensaje = resultSet.getString("mensaje");
                Queja queja = new Queja(id, correo, mensaje);
                quejasList.add(queja);
            }

            // Pasar la lista de quejas al JSP
            request.setAttribute("quejas", quejasList);
            request.getRequestDispatcher("/verQuejas.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            // Manejo de errores con mensaje amigable
            request.setAttribute("errorMessage", "Error al acceder a la base de datos. Inténtelo nuevamente más tarde.");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

    // Método para manejar la solicitud POST (enviar una nueva queja)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String correo = request.getParameter("correo");
        String mensaje = request.getParameter("mensaje");

        if (correo != null && !correo.trim().isEmpty() && mensaje != null && !mensaje.trim().isEmpty()) {
            // SQL para insertar una queja
            String sql = "INSERT INTO quejas (correo, mensaje) VALUES (?, ?)";

            try (Connection connection = getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

                preparedStatement.setString(1, correo);
                preparedStatement.setString(2, mensaje);

                int rowAffected = preparedStatement.executeUpdate();

                if (rowAffected > 0) {
                    // Redirigir a una página de confirmación
                    request.setAttribute("successMessage", "Queja enviada exitosamente.");
                    request.getRequestDispatcher("/confirmacion.jsp").forward(request, response);
                } else {
                    // Si la inserción falla, mostrar un mensaje de error
                    request.setAttribute("errorMessage", "Error al enviar la queja. Inténtalo nuevamente.");
                    request.getRequestDispatcher("/contacto.jsp").forward(request, response);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("errorMessage", "Error en la base de datos: " + e.getMessage());
                request.getRequestDispatcher("/contacto.jsp").forward(request, response);
            }
        } else {
            // Si faltan los parámetros, redirigir al formulario
            request.setAttribute("errorMessage", "Por favor, completa todos los campos.");
            request.getRequestDispatcher("/contacto.jsp").forward(request, response);
        }
    }
}

