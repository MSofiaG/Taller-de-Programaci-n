public class Certificado {
    private int id;
    private String nombreUsuario;
    private byte[] archivo;  // Usar un arreglo de bytes para almacenar el archivo
    private boolean aprobado;

    // Constructor
    public Certificado(int id, String nombreUsuario, byte[] archivo, boolean aprobado) {
        this.id = id;
        this.nombreUsuario = nombreUsuario;
        this.archivo = archivo;
        this.aprobado = aprobado;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public byte[] getArchivo() {
        return archivo;
    }

    public void setArchivo(byte[] archivo) {
        this.archivo = archivo;
    }

    public boolean isAprobado() {
        return aprobado;
    }

    public void setAprobado(boolean aprobado) {
        this.aprobado = aprobado;
    }
}
