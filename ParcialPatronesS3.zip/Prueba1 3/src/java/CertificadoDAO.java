import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CertificadoDAO {
    private Connection connection;

    public CertificadoDAO(Connection connection) {
        this.connection = connection;
    }

    // Guardar certificado en la base de datos
    public boolean guardarCertificado(Certificado certificado) throws SQLException {
        String query = "INSERT INTO certificados (nombre_usuario, archivo, aprobado) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, certificado.getNombreUsuario());
            stmt.setBytes(2, certificado.getArchivo());  // Guardar el archivo como un BLOB
            stmt.setBoolean(3, certificado.isAprobado());
            int rowsInserted = stmt.executeUpdate();
            return rowsInserted > 0;
        }
    }

    // Obtener certificados pendientes de aprobación
    public List<Certificado> obtenerCertificadosPendientes() throws SQLException {
        List<Certificado> certificados = new ArrayList<>();
        String query = "SELECT * FROM certificados WHERE aprobado = false";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Certificado certificado = new Certificado(
                    rs.getInt("id"),
                    rs.getString("nombre_usuario"),
                    rs.getBytes("archivo"),  // Recuperar el archivo como un arreglo de bytes
                    rs.getBoolean("aprobado")
                );
                certificados.add(certificado);
            }
        }
        return certificados;
    }

    // Aprobar certificado
    public void aprobarCertificado(int idCertificado) throws SQLException {
        String query = "UPDATE certificados SET aprobado = true WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, idCertificado);
            stmt.executeUpdate();
        }
    }
}
