import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SupermercadoDAO {
    private Connection connection;

    public SupermercadoDAO(Connection connection) {
        this.connection = connection;
    }

    public boolean registrarSupermercado(String nombre, String apellido, String nit, String correo, String contra, String telefono, int localidad) {
        String sql = "INSERT INTO supermercado (nombre, apellido, nit, correo, contra, telefono, localidad) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, nombre);
            statement.setString(2, apellido);
            statement.setString(3, nit);
            statement.setString(4, correo);
            statement.setString(5, contra);
            statement.setString(6, telefono);
            statement.setInt(7, localidad);
            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para verificar las credenciales del supermercado
    public boolean verificarCredenciales(String correo, String contra) {
        String sql = "SELECT COUNT(*) FROM supermercado WHERE correo = ? AND contra = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, correo);
            statement.setString(2, contra);
            
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                // Si el resultado es mayor que 0, las credenciales son correctas
                return resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
