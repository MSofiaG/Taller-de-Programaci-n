
import javax.servlet.RequestDispatcher;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 *
 * @author sofia
 */
@WebServlet(urlPatterns = {"/miServlet2"})
@MultipartConfig
public class miServlet2 extends HttpServlet {


    private static final String FOTO_RUTA = "C:/Users/marth/Downloads/";

    private void handleProductPublication(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        String fechaVencimiento = request.getParameter("fechaVencimiento");
        String producto = request.getParameter("producto");
        String precio = request.getParameter("precio");

        Part foto = request.getPart("foto");
        String fotoNombre = foto.getSubmittedFileName();
        String fotoRuta = FOTO_RUTA + fotoNombre;

        try (InputStream input = foto.getInputStream();
             FileOutputStream output = new FileOutputStream(fotoRuta)) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = input.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("Error al guardar la imagen", e);
        }

        request.setAttribute("nombre", nombre);
        request.setAttribute("descripcion", descripcion);
        request.setAttribute("fechaVencimiento", fechaVencimiento);
        request.setAttribute("producto", producto);
        request.setAttribute("precio", precio);
        request.setAttribute("foto", fotoNombre);

        RequestDispatcher dispatcher = request.getRequestDispatcher("index_4.jsp");
        dispatcher.forward(request, response);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    String action = request.getParameter("action");

    if (action != null) {
        action = action.trim(); // Elimina espacios en blanco antes o después del texto
        switch (action) {
            case "Publicar Producto":
                response.sendRedirect("index4Sup.html");
                break;
            case "Visualizar Productos":
                response.sendRedirect("index_4.jsp");
                break;
            case "Servicio Tecnico": // Asegúrate de que este valor sea idéntico al del formulario
                response.sendRedirect("index6Cli.html");
                break;
            default:
                response.getWriter().println("Acción no válida.");
                break;
        }
    } else {
        response.getWriter().println("Acción no proporcionada.");
    }
}

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}