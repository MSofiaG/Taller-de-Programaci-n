import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginCliServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener las credenciales de inicio de sesión
        String correo = request.getParameter("correoU");
        String contra = request.getParameter("contraU");

        // Verificar si el usuario existe en la base de datos
        try (Connection connection = ConexionBD.getConnection()) {
            ClienteDAO clienteDAO = new ClienteDAO(connection);
            boolean existeUsuario = clienteDAO.verificarCredenciales(correo, contra);
            boolean cuentaActiva = clienteDAO.verificarCuentaActiva(correo);

            if (existeUsuario) {
                if (cuentaActiva) {
                    // Redirigir a la página de inicio para usuarios autenticados
                    response.sendRedirect("index4Cli.html");
                } else {
                    // Redirigir con un mensaje de cuenta inactiva
                    response.sendRedirect("index1Cli.html?error=cuenta_inactiva");
                }
            } else {
                // Redirigir de nuevo al formulario de inicio de sesión con un mensaje de error
                response.sendRedirect("index1Cli.html?error=credenciales");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error en la conexión a la base de datos.");
        }
    }
}
