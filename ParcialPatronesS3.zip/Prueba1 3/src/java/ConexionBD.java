import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    // Datos de conexión a la base de datos
    private static final String URL = "jdbc:mysql://localhost:3306/CaminosSostenibles?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "giusepeymia";

    // Método para obtener una conexión a la base de datos
    public static Connection getConnection() throws SQLException {
        try {
            // Registrar el controlador JDBC (opcional)
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Obtener la conexión
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            System.out.println("Error al cargar el driver JDBC");
            e.printStackTrace();
            throw new SQLException("No se pudo cargar el driver JDBC", e);
        }
    }
}
