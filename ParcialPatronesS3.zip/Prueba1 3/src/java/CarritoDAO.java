import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CarritoDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/CaminosSostenibles?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "giusepeymia";

    // Método para agregar un producto al carrito
    public void agregarProductoAlCarrito(int carritoId, int productoId, int cantidad) {
        String sql = "INSERT INTO carritoItem (carritoId, productoId, Cantidad) VALUES (?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, carritoId);
            statement.setInt(2, productoId);
            statement.setInt(3, cantidad);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error al agregar producto al carrito", e);
        }
    }

    // Método para obtener todos los productos de un carrito específico (con detalles de producto)
    public List<CarritoItem> obtenerCarrito(int carritoId) throws SQLException {
        List<CarritoItem> carritoItems = new ArrayList<>();
        String sql = "SELECT ci.id as item_id, ci.carritoId, ci.productoId, ci.Cantidad, " +
                     "p.nombre, p.precio " +
                     "FROM carritoItem ci " +
                     "JOIN productos p ON ci.productoId = p.id " +
                     "WHERE ci.carritoId = ?";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, carritoId);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                CarritoItem item = new CarritoItem();
                item.setId(resultSet.getInt("item_id"));
                item.setCarritoId(resultSet.getInt("carritoId"));
                item.setProductoId(resultSet.getInt("productoId"));
                item.setCantidad(resultSet.getInt("Cantidad"));
                item.setNombre(resultSet.getString("nombre"));
                item.setPrecio(resultSet.getDouble("precio"));
                carritoItems.add(item);
            }
        }
        return carritoItems;
    }

    // Método para guardar todos los items del carrito en la base de datos al realizar el pago
    public void guardarCarrito(List<CarritoItem> carrito, int carritoId) throws SQLException {
        String sql = "UPDATE carritoItem SET carritoId = ? WHERE id = ?";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            for (CarritoItem item : carrito) {
                statement.setInt(1, carritoId);
                statement.setInt(2, item.getId());
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error al guardar el carrito", e);
        }
    }

    // Método opcional para crear un nuevo carrito si no existe uno en la sesión
    public int crearCarrito() {
        String sql = "INSERT INTO carrito (fecha_creacion) VALUES (NOW())";
        int carritoId = -1;

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            statement.executeUpdate();
            ResultSet keys = statement.getGeneratedKeys();

            if (keys.next()) {
                carritoId = keys.getInt(1); // Obtiene el ID generado para el nuevo carrito
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error al crear el carrito", e);
        }

        return carritoId;
    }
}
