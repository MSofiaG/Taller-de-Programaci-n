import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegistroSupServlet")
public class RegistroSupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener los parámetros del formulario
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String nit = request.getParameter("nit");
        String correo = request.getParameter("correo");
        String contra = request.getParameter("contra");
        String telefono = request.getParameter("tel");
        int localidad = Integer.parseInt(request.getParameter("localidad"));

        // Guardar en la base de datos
        try (Connection connection = ConexionBD.getConnection()) {
            SupermercadoDAO dao = new SupermercadoDAO(connection);
            if (dao.registrarSupermercado(nombre, apellido, nit, correo, contra, telefono, localidad)) {
                // Redirige a index3Sup.html después de guardar
                response.sendRedirect("index3Sup.html");
            } else {
                response.getWriter().println("Error al registrar el supermercado.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error en la conexión a la base de datos.");
        }
    }
}
