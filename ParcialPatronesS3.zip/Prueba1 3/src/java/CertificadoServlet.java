import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet(urlPatterns = {"/CertificadoServlet"})
@MultipartConfig(maxFileSize = 1024 * 1024 * 10) // Limite de 10MB por archivo
public class CertificadoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String RUTA_CERTIFICADOS = "C:/ruta/del/servidor/certificados/"; // Ruta en el servidor para guardar certificados

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String documento = request.getParameter("documento"); // Nombre del cliente
        Part certificadoPart = request.getPart("certificado"); // Archivo subido

        if (certificadoPart == null || certificadoPart.getSize() == 0) {
            response.getWriter().println("Error: No se subió ningún archivo.");
            return;
        }

        // Verifica que el archivo es un PDF
        String archivoNombre = certificadoPart.getSubmittedFileName();
        if (!archivoNombre.endsWith(".pdf")) {
            response.getWriter().println("Error: El archivo debe ser un PDF.");
            return;
        }

        // Guardar el archivo en el servidor
        File carpeta = new File(RUTA_CERTIFICADOS);
        if (!carpeta.exists()) {
            carpeta.mkdirs(); // Crea la carpeta si no existe
        }
        String rutaArchivo = RUTA_CERTIFICADOS + archivoNombre;
        File archivoDestino = new File(rutaArchivo);
        try (InputStream input = certificadoPart.getInputStream()) {
            Files.copy(input, archivoDestino.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }

        // Guardar la ruta del archivo en la base de datos
        try (Connection connection = ConexionBD.getConnection()) {
            String query = "INSERT INTO certificados (documento, certificado) VALUES (?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setString(1, documento);
                stmt.setString(2, rutaArchivo);

                int filasAfectadas = stmt.executeUpdate();
                if (filasAfectadas > 0) {
                    // Redirige a la página de notificación si el archivo fue subido correctamente
                    response.sendRedirect("notificacionE.jsp");
                } else {
                    response.getWriter().println("Error al guardar el certificado en la base de datos.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error al procesar el certificado: " + e.getMessage());
        }
    }
}
