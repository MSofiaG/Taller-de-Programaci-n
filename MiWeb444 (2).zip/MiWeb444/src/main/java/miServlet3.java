/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author marth
 */
@WebServlet(urlPatterns = {"/miServlet3"})
@MultipartConfig
public class miServlet3 extends HttpServlet {

    private static final String FOTO_RUTA = "C:/Users/marth/Downloads/";
    private static final String PRODUCTOS_RUTA = "C:/Users/marth/Downloads/Productos.txt";

    private void handleProductPublication(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        String fechaVencimiento = request.getParameter("fechaVencimiento");
        String producto = request.getParameter("producto");
        String precio = request.getParameter("precio");

        Part foto = request.getPart("foto");
        String fotoNombre = foto.getSubmittedFileName();
        String fotoRuta = FOTO_RUTA + fotoNombre;

        // Guardar la imagen
        try (InputStream input = foto.getInputStream(); FileOutputStream output = new FileOutputStream(fotoRuta)) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = input.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("Error al guardar la imagen", e);
        }

        // Agregar producto al archivo
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PRODUCTOS_RUTA, true))) {
            writer.write(String.format("%s,%s,%s,%s,%s,%s%n", nombre, descripcion, fechaVencimiento, producto, precio, fotoNombre));
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("Error al guardar el producto", e);
        }

        request.setAttribute("nombre", nombre);
        request.setAttribute("descripcion", descripcion);
        request.setAttribute("fechaVencimiento", fechaVencimiento);
        request.setAttribute("producto", producto);
        request.setAttribute("precio", precio);
        request.setAttribute("foto", fotoNombre);

        RequestDispatcher dispatcher = request.getRequestDispatcher("index_4.jsp");
        dispatcher.forward(request, response);
    }

    private void handleProductModification(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        String fechaVencimiento = request.getParameter("fechaVencimiento");
        String producto = request.getParameter("producto");
        String precio = request.getParameter("precio");

        Part foto = request.getPart("foto");
        String fotoNombre = foto.getSubmittedFileName();
        String fotoRuta = FOTO_RUTA + fotoNombre;

        // Guardar o reemplazar la foto
        try (InputStream input = foto.getInputStream(); FileOutputStream output = new FileOutputStream(fotoRuta)) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = input.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("Error al guardar la imagen", e);
        }

        // Leer productos y modificar el que coincide con el nombre
        List<String> productos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(PRODUCTOS_RUTA))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields[0].equals(nombre)) {
                    // Modificar el producto
                    productos.add(String.format("%s,%s,%s,%s,%s,%s", nombre, descripcion, fechaVencimiento, producto, precio, fotoNombre));
                } else {
                    productos.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("Error al leer el archivo de productos", e);
        }


        // Redirigir a index_4.jsp
        RequestDispatcher dispatcher = request.getRequestDispatcher("index_4.jsp");
        dispatcher.forward(request, response);
    }

    private void handleProductDeletion(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");

        // Leer productos y eliminar el que coincide con el nombre
        List<String> productos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(PRODUCTOS_RUTA))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (!fields[0].equals(nombre)) {
                    productos.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("Error al leer el archivo de productos", e);
        }

        // Sobrescribir el archivo con la lista actualizada
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PRODUCTOS_RUTA))) {
            for (String producto : productos) {
                writer.write(producto);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("Error al guardar el archivo de productos", e);
        }

        // Redirigir a index_4.jsp
        RequestDispatcher dispatcher = request.getRequestDispatcher("index_4.jsp");
        dispatcher.forward(request, response);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String action = request.getParameter("action");

        if (action != null) {
            switch (action) {
                case "Publicar":
                    handleProductPublication(request, response);
                    break;
                case "Modificar":
                    handleProductModification(request, response);
                    break;
                case "Eliminar":
                    handleProductDeletion(request, response);
                    break;
                default:
                    response.getWriter().println("Acción no válida.");
                    break;
            }
        } else {
            response.getWriter().println("Acción no proporcionada.");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
