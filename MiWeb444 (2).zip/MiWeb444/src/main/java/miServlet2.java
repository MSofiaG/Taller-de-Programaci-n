/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 *
 * @author sofia
 */
@WebServlet("/miServlet2")
@MultipartConfig
public class miServlet2 extends HttpServlet {


    private static final String FOTO_RUTA = "C:/Users/marth/Downloads/";

    private void handleProductPublication(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        String fechaVencimiento = request.getParameter("fechaVencimiento");
        String producto = request.getParameter("producto");
        String precio = request.getParameter("precio");

        Part foto = request.getPart("foto");
        String fotoNombre = foto.getSubmittedFileName();
        String fotoRuta = FOTO_RUTA + fotoNombre;

        try (InputStream input = foto.getInputStream();
             FileOutputStream output = new FileOutputStream(fotoRuta)) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = input.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("Error al guardar la imagen", e);
        }

        request.setAttribute("nombre", nombre);
        request.setAttribute("descripcion", descripcion);
        request.setAttribute("fechaVencimiento", fechaVencimiento);
        request.setAttribute("producto", producto);
        request.setAttribute("precio", precio);
        request.setAttribute("foto", fotoNombre);

        RequestDispatcher dispatcher = request.getRequestDispatcher("index_4.jsp");
        dispatcher.forward(request, response);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String action = request.getParameter("action");

        if (action != null) {
            switch (action) {
                case "Publicar Producto":
                case "Modificar Producto":
                case "Eliminar Producto":
                    // Redirigir a index_3.html para las acciones de publicar, modificar y eliminar
                    response.sendRedirect("index_3.html");
                    break;
                case "Promocionar Producto":
                    // Agregar lógica si es necesario para esta acción
                    response.getWriter().println("Promocionar Producto no está implementado.");
                    break;
                case "Servicio Tecnico":
                    response.sendRedirect("index_5.html");
                    break;
                default:
                    response.getWriter().println("Acción no válida.");
                    break;
            }
        } else {
            response.getWriter().println("Acción no proporcionada.");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}